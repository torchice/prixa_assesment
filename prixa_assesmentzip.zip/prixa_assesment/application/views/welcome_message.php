<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js" integrity="sha512-0QbL0ph8Tc8g5bLhfVzSqxe9GERORsKhIn1IrpxDAgUsbBGz/V7iSav2zzW325XGd1OMLdL4UiqRJj702IeqnQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.3/bootbox.min.js" integrity="sha512-U3Q2T60uOxOgtAmm9VEtC3SKGt9ucRbvZ+U3ac/wtvNC+K21Id2dNHzRUC7Z4Rs6dzqgXKr+pCRxx5CyOsnUzg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.3/bootbox.js" integrity="sha512-OMYI9iOelB12PWdWHfU6XouDuUvszFZEywO4W9KFJGP3aj/nP5UECd5ctMqRm+/9Qk3oOFqhbXVi6cJAqlAUuA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">  

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>

<head>
	<style>
		.form-search{
			width:fit-content;
		}
		::selection { background-color: #E13300; color: white; }
		::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
		text-decoration: none;
	}

	a:hover {
		color: #97310e;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
		min-height: 96px;
	}

	p {
		margin: 0 0 10px;
		padding:0;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}
	.dataTables_length{
		margin:10px 0px;
	}
	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
		#container{
			padding:20px;
		}
		.bi-info-circle-fill{
			margin-left:10px;
		}
		tbody,td,tfoot,th,thead,tr{
			border-color:inherit;
			border-style:solid;
			border-width:1;
			padding:10px;

		}
		.bootbox-body{
			text-align:center;
		}
		.bootbox-accept{
			height:32px;
			display:flex;
			align-items:center;
			font-size:12px;
		}
		.bootbox-cancel{
			height:32px;
			display:flex;
			align-items:center;
			font-size:12px;
		}
	</style>


<script>
	var boolUpdate=false;
	function errorNumber(){
		bootbox.alert({
			title:"Warning ",
			centerVertical:true,
			message: "Inputan hanya boleh angka",
			backdrop: true,
			closeButton:false
		});
	}
	
	function save(){
		console.log('masuk save');
		const myDataObject = {
				"descriptions": "berubah",
				"genre": "berubah",
				"title": "codezup code the way up",
				"views": 6969
			};

			const putData = async ( ) =>{
			const response = await fetch('https://andywiranata-42555.firebaseio.com/test-frontend/items.json', {
				method: 'PUT', 
				headers: {
					'Content-Type': 'application/json'
				},
				data: JSON.stringify(myDataObject)
			});

		}

	}
	function showModal(msg){
		bootbox.alert({
			centerVertical:true,
			message: msg,
			backdrop: true,
			closeButton:false
		});
	}

	function confirmation(idBtn){
		bootbox.confirm({
				message: "Are you sure to save the data?",
				title:"Confirmation ",
				buttons: {
					confirm: {
						label: 'Yes',
						className: 'btn-success'
					},
					cancel: {
						label: 'No',
						className: 'btn-danger'
					}
				},
				callback: function (result) {
					if(result==true){
						$(idBtn).addClass("btn-primary");
						$(idBtn).removeClass("btn-danger");
						$(idBtn).html("<i class='bi bi-pencil-fill'></i>");
						save();
						console.log("true cc");
						get_data();
					}else{
						console.log("false cc");
					}
					//console.log('This was logged in the callback: ' + result);
				
				},
				closeButton:false
			});
	}

	function edit(id){
		//alert(e);
		var idBtn="#edit-"+id;
		if($(idBtn).hasClass("btn-primary")==true){
			$(idBtn).removeClass("btn-primary");
			$(idBtn).addClass("btn-danger");
			$(idBtn).html("<i class='bi bi-save'></i>");
			var idTitleSelector="#title-"+id;
			var idViewSelector="#view-"+id;
			var idDescSelector="#desc-"+id;
			var idGenreSelector="#genre-"+id;
			var idTitle="title-"+id;
			var idView="view-"+id;
			var idDesc="desc-"+id;
			var idGenre="genre-"+id;
			//console.log(id);
			var prevValue=$(idTitleSelector).text();
			var prevValue2=$(idViewSelector).text();
			var prevValue3=$(idDescSelector).text();
			var prevValue4=$(idGenreSelector).text();
			var inputText="<input id='"+idTitle+"' type='text' value='"+prevValue+"'>";
			var inputText2="<input id='"+idView+"' type='text' min='1' class='form-control-numbers' value='"+prevValue2+"'>";
			var inputText3="<input id='"+idDesc+"' type='text' value='"+prevValue3+"'>";
			var inputText4="<input id='"+idGenre+"' type='text' value='"+prevValue4+"'>";
			$(idTitleSelector).html(inputText);
			$(idViewSelector).html(inputText2);
			$(idDescSelector).html(inputText3);
			$(idGenreSelector).html(inputText4);
		}else{
			confirmation(idBtn);
		
		}
	
	
		console.log("hellow");
		//console.log(e);
	
		//alert(prevValue);

		//alert(idTitle);
	
		console.log("masuk");
		//var id=id.split("-");
	
		//console.log(id[1]);
		//$("")

	}

	function get_data(){
		console.log("hee");
		$("#table_anime_2").html("");
		var thead="<thead>"+
			"<tr>"+
				"<th>No</th>"+
				"<th>Title</th>"+
				"<th>Views</th>"+
				"<th>Genre</th>"+
				"<th>Descriptions</th>"+
				"<th>Actions</th>"+
			"</tr>"+
		"</thead>";
		$("#table_anime_2").append(thead);
		$.ajax({
                url: 'https://andywiranata-42555.firebaseio.com/test-frontend/items.json',
                type: 'GET',
				dataType:"json",
            }).done(function (result) {
				console.log(result);
				var test1 = JSON.stringify(result);
				console.log("test1");
				console.log(test1);
				/*var test2=JSON.parse(result);
				console.log("test2");
				console.log(test2);
				*/
				var resultArr=[];
				console.log("hhhhh");
				for(var i in result){
					resultArr.push([result[i]]);
				}
				console.log("JSON ARR");
				console.log(resultArr);
				$("#table_anime_2").append("<tbody>");
				var searchHtml="<input class='form-control form-search' id='myInput' type='text' placeholder='Search..'>";
				var searchHtml2="<input class='form-control form-search' id='myInput2' type='text' placeholder='Search..'>";
				$("#table_anime_2").append("<tr><td></td><td>"+searchHtml+"</td><td></td><td>"+searchHtml2+"</td></tr>");

				$.each(result,function(index,value){
					console.log(index);
					var counter=parseInt(index+1);
				
					$("#table_anime_2").append("<tr  class='title'>"+"<td>"+
						counter+"</td><td class='title-search' id='title-"+index+"'>"+
							value["title"]+
						"</td><td id='view-"+index+"'>"+
							value["views"]+
						"</td><td id='genre-"+index+"' class='genre-search'>"+
							value["genre"]+
						"</td><td id='desc-"+index+"'>"+
							value["descriptions"]+
							"<i class='bi bi-info-circle-fill' onclick='showModal("+
							'\"'+
								value["descriptions"].replace(/'|\n/g,'')+
							'\"'+
						")' ></i>"+
						"</td><td>"+
							"<button id='edit-"+index+"' onclick='edit("+index+")' class='btn btn-primary' style='border-radius:60px;'><i class='bi bi-pencil-fill'></i></button>"+
						"</td>"+
						"</tr>");
					console.log(value["descriptions"]);
				})
				console.log("testIndex");
				console.log(result.length);

				var index=1;
				
				var description=result[0].descriptions;
				console.log(result[0].descriptions);
				console.log("hello");
				$("#table_anime_2").append("</tbody>");
            }).fail(function () {
   
        })
	}
	
</script>
<script>
	$(function(){
		get_data();
		$("#showFilter1").on("click",function(){
			//alert($(".form-search").is(":visible"));
			var visibilitySearch=$(".form-search").is(":visible");
			if(visibilitySearch==false){
				$(".form-search").show();
			}else{
				$(".form-search").hide();
			}
		
		})

		$(document).on("focusout",".form-control-numbers",function(e){
			var id = "#"+e.currentTarget.id;
			console.log("focusout");
			console.log(id);
			var valid = $(id).val();
			if(valid=="" || valid==0){
				console.log("masuk");
				$(this).val(1);
			}
		})

		$(document).on("paste","form-control-numbers",function(e){
			console.log("paste");
			if(e.originalEvent.clipboardData.getData("text").match(/[^\d]/)){
				e.preventDefault();
			}
		})

		$(document).on("keypress",".form-control-numbers",function(e){
			e=e || window.event;
			var code = e.keyCode;
			if(code >= 48 && code <= 57){
				return code;

			}else{
				if(e.which != 8 && e.which != 0 && e.which != 13 && (e.which < 48 || e.which >57)){
					errorNumber();
					return false;
				}
			}
		})
	

		$(document).on("keyup","#myInput",function(){
			var value = $(this).val().toLowerCase();
			$("#table_anime_2 > .title").filter(function() {
				$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		})

		$(document).on("keyup","#myInput2",function(){
		
			var value = $(this).val().toLowerCase();
			$(".title > .genre-search").filter(function() {
				$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		})
	
		//$(".dataTables_empty").hide();
		$("#myInput").hide();
	});

	$(document).ajaxComplete(function() {
		
		$(".form-search").hide();
		$("#table_anime_2").DataTable({
			searching: false,
			"paging" : true
		});
	});
	
     
		
</script>

</head>
<body>

<div id="container">
	<button id="showFilter1" class="btn btn-primary">Filter</button>

	<table id="table_anime_2">
	
	
	</table>

</body>
</html>
