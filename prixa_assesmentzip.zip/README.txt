1. Install Xampp jika belum ada.
2. Copykan folder ke dalam htdocs
3. Jalankan http://localhost/prixa_assesment/
